import 'package:flutter/material.dart';
import './categories_screen.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DeliMeals',
      theme: ThemeData(
        fontFamily: 'NotoSerif',
        primarySwatch: Colors.pink,
        accentColor: Colors.amber,
        textTheme: ThemeData.light().textTheme.copyWith(
          body2: TextStyle(color:
          Color.fromARGB(20, 51, 51, 1),
          ),
          body1: TextStyle(color:
          Color.fromARGB(20, 51, 51, 1),
          ),


          title: TextStyle(
            fontSize: 20,
            fontFamily: 'PTSans',
            fontWeight: FontWeight.bold,
            color: Colors.black,
          )
        ),
      ),
      home: CategoriesScreen(),
    );
  }
}


